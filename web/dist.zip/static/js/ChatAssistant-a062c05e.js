import{_ as t}from"./ChatAssistant.vue_vue_type_style_index_0_lang-ed32d0e1.js";import"./index-10dc8ceb.js";export{t as default};
