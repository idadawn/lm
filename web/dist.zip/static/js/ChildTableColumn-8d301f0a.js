import{_ as e}from"./ChildTableColumn.vue_vue_type_script_setup_true_lang-81b17a96.js";export{e as default};
