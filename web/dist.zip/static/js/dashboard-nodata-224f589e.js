const a="/static/png/dashboard-nodata-85c6802e.png";export{a as _};
