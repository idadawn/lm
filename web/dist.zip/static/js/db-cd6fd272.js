const t="drawingItems";function e(){const e=localStorage.getItem(t);return e?JSON.parse(e):null}function n(e){localStorage.setItem(t,JSON.stringify(e))}export{e as g,n as s};
